# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| v0.0.1  | :x: |

## Reporting a Vulnerability

To Report a Vulnerability please go to the issue tab and create a new issue with the tag Security Issue
