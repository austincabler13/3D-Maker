bl_info = {
    "name": "3D-Maker",
    "blender": (4, 2, 3),
    "category": "3D View",
    "author": "Austin Cabler",
    "version": (0, 1, 4),
    "description": "A plugin for Blender that uses Meshy's API to create models",
    "support": "COMMUNITY",
    "url": "https://github.com/austincabler13/3D-Maker/",
}

# Importing the necessary classes from the plugin module
from .plugin import MeshyOperator, MeshyPanel

def register():
    # Registering the operator and panel
    bpy.utils.register_class(MeshyOperator)
    bpy.utils.register_class(MeshyPanel)

def unregister():
    # Unregistering the operator and panel
    bpy.utils.unregister_class(MeshyPanel)
    bpy.utils.unregister_class(MeshyOperator)

if __name__ == "__main__":
    register()
