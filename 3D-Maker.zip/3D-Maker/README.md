# 👋🏻 3D Maker

A plugin for blender that uses Mushy's API to create models

## 💀No professional

I am no professional so if you contribute keep that in mind

## 🤷🏻‍♂️ Faqs

## How to Download and use this plugin?

- Coming Soon
  
### When is the Release Date

- This is still in Development has we do not have a Main release date at this moment

### How do I Contribute/Donate/Help

- We do not have that option Right now but wants we get everything going I will let you know on what to do to contribute.

## 🗒️ Note

- We are not with Mushy or their Brand.
- We do Not own the API
- We do Not sell this plugin for money or intend to sell it for money

### 📣 License

This Repository is Licensed with Apache 2.0
